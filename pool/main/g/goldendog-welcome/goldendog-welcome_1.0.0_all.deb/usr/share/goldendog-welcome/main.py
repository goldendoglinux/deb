#!/usr/bin/env python3
import sys
import os

# Add src to path
# We must use realpath because this script is symlinked to /usr/bin/goldendog-welcome
basedir = os.path.dirname(os.path.realpath(__file__))
sys.path.append(os.path.join(basedir, 'src'))

from application import GoldenDogWelcomeApplication

def main():
    app = GoldenDogWelcomeApplication()
    return app.run(sys.argv)

if __name__ == '__main__':
    sys.exit(main())
