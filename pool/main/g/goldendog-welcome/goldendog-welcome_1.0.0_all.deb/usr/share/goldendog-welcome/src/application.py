import gi

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')

from gi.repository import Gtk, Gio, Adw
from window import GoldenDogWelcomeWindow

class GoldenDogWelcomeApplication(Adw.Application):
    def __init__(self):
        super().__init__(application_id='org.goldendoglinux.welcome',
                         flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = self.props.active_window
        if not win:
            win = GoldenDogWelcomeWindow(application=self)
        win.present()
