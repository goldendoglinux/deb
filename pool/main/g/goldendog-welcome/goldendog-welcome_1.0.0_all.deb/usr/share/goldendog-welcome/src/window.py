import gi

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')

from gi.repository import Gtk, Adw, Gdk
import os
import gettext
import locale

# Setup i18n
# We look for the 'locale' directory in system path first, then relative
SYSTEM_LOCALE_DIR = "/usr/share/locale"
LOCAL_LOCALE_DIR = os.path.join(os.path.dirname(__file__), "..", "locale")

if os.path.exists(os.path.join(SYSTEM_LOCALE_DIR, "es", "LC_MESSAGES", "goldendog-welcome.mo")):
    LOCALE_DIR = SYSTEM_LOCALE_DIR
else:
    LOCALE_DIR = LOCAL_LOCALE_DIR

gettext.bindtextdomain('goldendog-welcome', LOCALE_DIR)
gettext.textdomain('goldendog-welcome')
_ = gettext.gettext

class GoldenDogWelcomeWindow(Adw.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.set_title(_("Welcome to GoldenDog Linux"))
        # Set fixed size to prevent the issue of seeing multiple slides when maximized
        # and to match the "small, centered" look of gnome-welcome.
        # User requested expansion to fix "sloppy" cramping and overlap issues.
        self.set_default_size(850, 650)
        self.set_resizable(False)

        # Toast Overlay
        # Adw.ApplicationWindow doesn't have add_toast in some versions, or usage requires overlay
        self.toast_overlay = Adw.ToastOverlay()
        self.set_content(self.toast_overlay)

        # Main content box
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        # self.set_content(self.main_box) -> Moved to be child of overlay
        self.toast_overlay.set_child(self.main_box)

        # Header Bar - remove window controls if we want it to look like a strict dialog?
        # Standard Adwaita apps usually keep them. We'll keep them but the window is fixed size.
        self.header_bar = Adw.HeaderBar()
        self.header_bar.add_css_class("flat") # cleaner look
        self.main_box.append(self.header_bar)

        # Content Area - Horizontal box to hold [Prev] [Carousel] [Next]
        self.content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.content_box.set_hexpand(True)
        self.content_box.set_vexpand(True)
        self.main_box.append(self.content_box)

        # Previous Button
        self.prev_btn = Gtk.Button()
        self.prev_btn.add_css_class("flat")
        self.prev_btn.set_valign(Gtk.Align.CENTER)
        self.prev_btn.set_margin_start(8)
        
        # Load custom prev icon
        prev_icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "go-previous.svg")
        if os.path.exists(prev_icon_path):
            img = Gtk.Image.new_from_file(prev_icon_path)
            # Make arrows larger (approx 2x standard)
            img.set_pixel_size(48)
            self.prev_btn.set_child(img)
        else:
            self.prev_btn.set_icon_name("go-previous-symbolic")
            
        self.prev_btn.connect("clicked", self._on_prev_clicked)
        self.content_box.append(self.prev_btn)

        # Carousel
        self.carousel = Adw.Carousel()
        self.carousel.set_hexpand(True)
        self.carousel.set_vexpand(True)
        self.carousel.connect("page-changed", self._on_page_changed)
        self.content_box.append(self.carousel)
        
        # Next Button
        self.next_btn = Gtk.Button()
        self.next_btn.add_css_class("flat")
        self.next_btn.set_valign(Gtk.Align.CENTER)
        self.next_btn.set_margin_end(8)
        
        # Load custom next icon
        next_icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "go-next.svg")
        if os.path.exists(next_icon_path):
            img = Gtk.Image.new_from_file(next_icon_path)
            # Make arrows larger (approx 2x standard)
            img.set_pixel_size(48)
            self.next_btn.set_child(img)
        else:
            self.next_btn.set_icon_name("go-next-symbolic")

        self.next_btn.connect("clicked", self._on_next_clicked)
        self.content_box.append(self.next_btn)

        # --- SLIDES ---
        self._build_welcome_slide()
        self._build_eula_slide()
        self._build_telemetry_slide()
        self._build_finish_slide()

        # Carousel Indicator - dots at the bottom
        self.dots = Adw.CarouselIndicatorDots()
        self.dots.set_carousel(self.carousel)
        self.dots.set_margin_bottom(16)
        self.main_box.append(self.dots)
        
        # Initial button state update
        self._on_page_changed(self.carousel, 0)

    def _build_welcome_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("Welcome to GoldenDog Linux"))
        page.set_description(_("Thank you for choosing GoldenDog. Let's get you set up."))
        # Force the page to fill the carousel area so we don't see neighbors
        page.set_hexpand(True)
        page.set_vexpand(True)
        
        # Load custom icon
        # We use a Gtk.Picture for the custom image as the 'child' of the status page
        # This renders below the description, which looks fine and is reliable.
        # Load custom icon
        # We use a Gtk.Picture for the custom image as the 'child' of the status page
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "gdl-icon.svg")
        
        if os.path.exists(icon_path):
            # Using Gtk.Picture is often better for scalable graphics than Gtk.Image
            texture = Gdk.Texture.new_from_filename(icon_path)
            page.set_paintable(texture)
        else:
            page.set_icon_name("start-here-symbolic")
            
        self.carousel.append(page)

    def _build_eula_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("License Agreement"))
        page.set_description(_("Please review and accept the terms to proceed."))
        # Icon removed to make more room for content
        # Force layout fill
        page.set_hexpand(True)
        page.set_vexpand(True)

        # Clamp for better layout
        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)
        
        # Box for content
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        clamp.set_child(box)

        # Scrolled Window for EULA text
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_min_content_height(350)
        scrolled.set_vexpand(True)
        
        # Frame for visual containment
        frame = Gtk.Frame()
        frame.set_child(scrolled)
        box.append(frame)
        
        # Load license text
        license_path = os.path.join(os.path.dirname(__file__), "..", "assets", "agpl-3.0.txt")
        license_content = _("AGPL v3 License text could not be loaded.")
        if os.path.exists(license_path):
            try:
                with open(license_path, 'r', encoding='utf-8') as f:
                    license_content = f.read()
            except Exception as e:
                print(f"Error reading license: {e}")
        
        eula_text = Gtk.Label(label=license_content)
        eula_text.set_wrap(True)
        eula_text.set_selectable(True)
        eula_text.set_margin_top(12)
        eula_text.set_margin_bottom(12)
        eula_text.set_margin_start(12)
        eula_text.set_margin_end(12)
        # Use monospace for license text
        eula_text.add_css_class("monospace")
        scrolled.set_child(eula_text)

        # Checkbox
        self.eula_check = Gtk.CheckButton(label=_("I accept the terms of the license"))
        self.eula_check.set_halign(Gtk.Align.CENTER)
        self.eula_check.set_margin_top(12)
        box.append(self.eula_check)

        page.set_child(clamp)
        self.carousel.append(page)

    def _build_telemetry_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("Data & Privacy"))
        page.set_description(_("Choose how you want to contribute."))
        
        # Custom Icon: candado.svg
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "candado.svg")
        if os.path.exists(icon_path):
            texture = Gdk.Texture.new_from_filename(icon_path)
            page.set_paintable(texture)
        else:
            page.set_icon_name("preferences-system-privacy-symbolic")
            
        # Force layout fill
        page.set_hexpand(True)
        page.set_vexpand(True)
        
        # Clamp the content width - increased for better readability
        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)
        
        # Preferences Group
        # We can add a description to the group for more context
        group = Adw.PreferencesGroup()
        group.set_description(_("Your privacy is important. No personal data is collected."))
        clamp.set_child(group)
        
        # Plasma Telemetry
        plasma_row = Adw.ActionRow()
        plasma_row.set_title(_("KDE Plasma Telemetry"))
        plasma_row.set_subtitle(_("Send anonymous usage data to KDE to help improve the desktop experience."))
        self.plasma_switch = Gtk.Switch()
        self.plasma_switch.set_active(False)
        self.plasma_switch.set_valign(Gtk.Align.CENTER)
        plasma_row.add_suffix(self.plasma_switch)
        group.add(plasma_row)
        
        # Debian Telemetry
        debian_row = Adw.ActionRow()
        debian_row.set_title(_("Debian Popularity Contest"))
        debian_row.set_subtitle(_("Submit anonymous package usage statistics to help Debian decide what to include."))
        self.debian_switch = Gtk.Switch()
        self.debian_switch.set_active(False)
        self.debian_switch.set_valign(Gtk.Align.CENTER)
        debian_row.add_suffix(self.debian_switch)
        group.add(debian_row)
        
        page.set_child(clamp)
        self.carousel.append(page)

    def _build_finish_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("You're All Set!"))
        page.set_description(_("Review your choices and start using your system."))
        
        # Custom Icon: gdl-icon.svg (repeating the welcome icon)
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "gdl-icon.svg")
        if os.path.exists(icon_path):
            texture = Gdk.Texture.new_from_filename(icon_path)
            page.set_paintable(texture)
        else:
            page.set_icon_name("emblem-ok-symbolic")
            
        # Force layout fill
        page.set_hexpand(True)
        page.set_vexpand(True)
        
        btn = Gtk.Button(label=_("Start Using GoldenDog"))
        btn.add_css_class("pill")
        btn.add_css_class("suggested-action")
        btn.set_halign(Gtk.Align.CENTER)
        btn.set_margin_top(24)
        btn.connect("clicked", self._on_finish_clicked)
        
        # We append the button to the page content
        # Adw.StatusPage has a 'child' property
        page.set_child(btn)
        
        self.carousel.append(page)

    def _on_finish_clicked(self, button):
        # Validation
        if not self.eula_check.get_active():
            # Show error or toast
            toast = Adw.Toast.new(_("You must accept the license agreement to proceed."))
            self.toast_overlay.add_toast(toast)
            # Scroll back to EULA page (index 1)
            self.carousel.scroll_to(self.carousel.get_nth_page(1), True)
            return

        # Get telemetry states
        # We need to access the switches. I'll need to store references to them in _build_telemetry_slide
        plasma = self.plasma_switch.get_active()
        debian = self.debian_switch.get_active()

        from config import save_preferences
        if save_preferences(True, plasma, debian):
            print("Settings saved.")
            self.close()
        else:
            toast = Adw.Toast.new(_("Error saving settings."))
            self.toast_overlay.add_toast(toast)

    def _on_prev_clicked(self, button):
        idx = self.carousel.get_position()
        if idx > 0:
            self.carousel.scroll_to(self.carousel.get_nth_page(idx - 1), True)

    def _on_next_clicked(self, button):
        idx = self.carousel.get_position()
        n_pages = self.carousel.get_n_pages()
        if idx < n_pages - 1:
            self.carousel.scroll_to(self.carousel.get_nth_page(idx + 1), True)

    def _on_page_changed(self, carousel, index):
        # Update button states based on current page
        idx = carousel.get_position()
        n_pages = carousel.get_n_pages()
        
        # Simple sensitivity/visibility
        self.prev_btn.set_sensitive(idx > 0)
        
        # On last page, next button could be hidden or disabled since we have a big "Finish" button
        if idx >= n_pages - 1:
            self.next_btn.set_opacity(0)
            self.next_btn.set_sensitive(False)
        else:
            self.next_btn.set_opacity(1)
            self.next_btn.set_sensitive(True)
